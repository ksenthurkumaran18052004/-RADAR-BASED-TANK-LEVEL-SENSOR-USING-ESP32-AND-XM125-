var searchData=
[
  ['b_5fangle_5flength_2943',['B_ANGLE_LENGTH',['../ref__app__breathing_8c.html#acecdd89cb1aa03c3a2a6d2da3d8cd57e',1,'ref_app_breathing.c']]],
  ['b_5fstatic_5flength_2944',['B_STATIC_LENGTH',['../ref__app__breathing_8c.html#ae0ef1fbf99fc065725950da5caad6d69',1,'ref_app_breathing.c']]],
  ['buf_5fsize_2945',['BUF_SIZE',['../acc__wrap__printf_8c.html#a6821bafc3c88dfb2e433a095df9940c6',1,'acc_wrap_printf.c']]]
];
