var searchData=
[
  ['zone_5fdetection_1712',['zone_detection',['../structacc__smart__presence__zone__result__t.html#a30492bf9c724900c0fe75e89dbe39b51',1,'acc_smart_presence_zone_result_t']]],
  ['zone_5flimit_1713',['zone_limit',['../structacc__smart__presence__zone__result__t.html#ac9f76d4bb45b5da795de78d7fe573ccf',1,'acc_smart_presence_zone_result_t']]],
  ['zone_5flimits_1714',['zone_limits',['../structapp__context__t.html#a630b93c2a4fe7b9532d7376e074d0528',1,'app_context_t']]],
  ['zone_5fresults_1715',['zone_results',['../structacc__smart__presence__result__t.html#a2f25d1296da03496a77cb4ae7c668abb',1,'acc_smart_presence_result_t::zone_results()'],['../structapp__context__t.html#a317b83aa254116ec3b8eb0e5a4227733',1,'app_context_t::zone_results()']]]
];
