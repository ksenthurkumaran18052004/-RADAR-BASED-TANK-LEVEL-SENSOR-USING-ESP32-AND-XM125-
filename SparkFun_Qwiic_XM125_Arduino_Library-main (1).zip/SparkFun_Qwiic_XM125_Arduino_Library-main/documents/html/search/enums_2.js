var searchData=
[
  ['distance_5fpreset_5fconfig_5ft_2826',['distance_preset_config_t',['../example__detector__distance__with__iq__data__print_8c.html#af39f5adb2cee89b22043ae1ed1b01e14',1,'distance_preset_config_t():&#160;example_detector_distance_with_iq_data_print.c'],['../example__detector__distance_8c.html#af39f5adb2cee89b22043ae1ed1b01e14',1,'distance_preset_config_t():&#160;example_detector_distance.c']]]
];
