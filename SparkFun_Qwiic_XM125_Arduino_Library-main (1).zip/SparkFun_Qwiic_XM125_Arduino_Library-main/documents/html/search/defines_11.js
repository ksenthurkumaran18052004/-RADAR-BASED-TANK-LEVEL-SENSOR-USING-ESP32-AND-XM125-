var searchData=
[
  ['vdd_5fvalue_3429',['VDD_VALUE',['../stm32l4xx__hal__conf_8h.html#aae550dad9f96d52cfce5e539adadbbb4',1,'stm32l4xx_hal_conf.h']]],
  ['vprintf_3430',['vprintf',['../printf_8h.html#a275497dfccfba8ca97e73865fd2b083b',1,'printf.h']]],
  ['vsnprintf_3431',['vsnprintf',['../printf_8h.html#a00ba2ca988495904efc418acbf0627d7',1,'printf.h']]]
];
