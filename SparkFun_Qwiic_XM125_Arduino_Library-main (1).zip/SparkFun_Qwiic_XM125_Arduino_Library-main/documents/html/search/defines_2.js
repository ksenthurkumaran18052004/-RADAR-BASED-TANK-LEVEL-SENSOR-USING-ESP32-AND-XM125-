var searchData=
[
  ['config_5fhwaas_2946',['CONFIG_HWAAS',['../example__surface__velocity_8c.html#ad38150a979c6b3c392e52a83df1880e7',1,'example_surface_velocity.c']]],
  ['config_5fpsd_5flp_5fcoeff_2947',['CONFIG_PSD_LP_COEFF',['../example__surface__velocity_8c.html#a636b344ee2454095c86e0900e61e8def',1,'example_surface_velocity.c']]],
  ['config_5fsensor_5fangle_2948',['CONFIG_SENSOR_ANGLE',['../example__surface__velocity_8c.html#ac8376b91b417dd0c24490b02b1c750e4',1,'example_surface_velocity.c']]],
  ['config_5fsurface_5fdistance_2949',['CONFIG_SURFACE_DISTANCE',['../example__surface__velocity_8c.html#a0749d0b5c7c5457929c76588c528e92f',1,'example_surface_velocity.c']]],
  ['config_5fsweep_5frate_2950',['CONFIG_SWEEP_RATE',['../example__surface__velocity_8c.html#adb81b5b1cfd6ecbe396debbbec8150ac',1,'example_surface_velocity.c']]],
  ['config_5fthreshold_5fsensitivity_2951',['CONFIG_THRESHOLD_SENSITIVITY',['../example__surface__velocity_8c.html#ad5d7da6977c1ac45c589146306118e6a',1,'example_surface_velocity.c']]],
  ['config_5fvelocity_5flp_5fcoeff_2952',['CONFIG_VELOCITY_LP_COEFF',['../example__surface__velocity_8c.html#a6a8e45f4cc4c5bb42640a58a68dbdbb3',1,'example_surface_velocity.c']]]
];
