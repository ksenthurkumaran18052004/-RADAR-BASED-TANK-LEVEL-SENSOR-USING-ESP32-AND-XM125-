var searchData=
[
  ['nbr_5fconfigs_3203',['NBR_CONFIGS',['../example__detector__presence__multiple__configurations_8c.html#a1fec70214cc8646925d859f523644224',1,'NBR_CONFIGS():&#160;example_detector_presence_multiple_configurations.c'],['../example__service__multiple__configurations_8c.html#a1fec70214cc8646925d859f523644224',1,'NBR_CONFIGS():&#160;example_service_multiple_configurations.c']]],
  ['nbr_5fiterations_5fper_5fconfig_3204',['NBR_ITERATIONS_PER_CONFIG',['../example__detector__presence__multiple__configurations_8c.html#a2ac6b8300e1d163f92de795e1653fa50',1,'example_detector_presence_multiple_configurations.c']]]
];
