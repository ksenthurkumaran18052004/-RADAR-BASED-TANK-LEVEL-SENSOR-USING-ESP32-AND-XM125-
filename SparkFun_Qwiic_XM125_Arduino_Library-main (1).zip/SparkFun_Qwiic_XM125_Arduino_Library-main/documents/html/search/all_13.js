var searchData=
[
  ['validate_5fconfig_1687',['validate_config',['../example__surface__velocity_8c.html#a01ceb7e7eeec8ec3edb937d461481ef1',1,'validate_config(acc_surface_velocity_config_t *config):&#160;example_surface_velocity.c'],['../ref__app__breathing_8c.html#a315436b3613d4d355f286b0892552563',1,'validate_config(acc_breathing_config_t *config):&#160;ref_app_breathing.c']]],
  ['vdd_5fvalue_1688',['VDD_VALUE',['../stm32l4xx__hal__conf_8h.html#aae550dad9f96d52cfce5e539adadbbb4',1,'stm32l4xx_hal_conf.h']]],
  ['velocity_5flp_5fcoeff_1689',['velocity_lp_coeff',['../structacc__surface__velocity__config__t.html#a8128cbd7707eb20cc1877feca6370ccf',1,'acc_surface_velocity_config_t']]],
  ['vertical_5fv_1690',['vertical_v',['../structacc__surface__velocity__handle__t.html#a8a764ad94b185e4f9e611ac2e7ac526f',1,'acc_surface_velocity_handle_t']]],
  ['vprintf_1691',['vprintf',['../printf_8h.html#a275497dfccfba8ca97e73865fd2b083b',1,'printf.h']]],
  ['vprintf_5f_1692',['vprintf_',['../printf_8h.html#aa199d9388f8dcddcda1a0451315cae89',1,'vprintf_(const char *format, va_list va):&#160;printf.c'],['../printf_8c.html#aa199d9388f8dcddcda1a0451315cae89',1,'vprintf_(const char *format, va_list va):&#160;printf.c']]],
  ['vsnprintf_1693',['vsnprintf',['../printf_8h.html#a00ba2ca988495904efc418acbf0627d7',1,'printf.h']]],
  ['vsnprintf_5f_1694',['vsnprintf_',['../printf_8h.html#af37254f8c6a2d9d51e82c85fd666f88e',1,'vsnprintf_(char *buffer, size_t count, const char *format, va_list va):&#160;printf.c'],['../printf_8c.html#af37254f8c6a2d9d51e82c85fd666f88e',1,'vsnprintf_(char *buffer, size_t count, const char *format, va_list va):&#160;printf.c']]]
];
