var group__sensor =
[
    [ "acc_sensor_t", "group__sensor.html#ga8197ee238bf2e0c2e35fa2da5e772561", null ],
    [ "acc_sensor_calibrate", "group__sensor.html#gac6bf5a4d9554d4d66965fa94773ae0cb", null ],
    [ "acc_sensor_connected", "group__sensor.html#ga2bf4845d8c1108bc1e2faa69f83596bb", null ],
    [ "acc_sensor_create", "group__sensor.html#gae6a7fb9c8dc2a9f2865471d9e98f98e2", null ],
    [ "acc_sensor_destroy", "group__sensor.html#ga10265cca69d066625e8b31ce217f584a", null ],
    [ "acc_sensor_get_cal_info", "group__sensor.html#ga892173078ba27da88008dfc0796e4c91", null ],
    [ "acc_sensor_hibernate_off", "group__sensor.html#ga191499f8fea2af6defa51747dfae677e", null ],
    [ "acc_sensor_hibernate_on", "group__sensor.html#ga004d69f1c6100817e0eda59c149f8c19", null ],
    [ "acc_sensor_measure", "group__sensor.html#ga11ee1e17c25da43d7b82ffc9431bd906", null ],
    [ "acc_sensor_prepare", "group__sensor.html#gae5da98eeb54dac0b0a8f0b16f5d8ad67", null ],
    [ "acc_sensor_read", "group__sensor.html#ga19289bee1cf35c8c9f1a7c95831ef38b", null ],
    [ "acc_sensor_status", "group__sensor.html#ga2ee64745e66ece0231ee9caeb7e3f980", null ],
    [ "acc_sensor_validate_calibration", "group__sensor.html#gab41ef73ed669e8565d609f32a35979ed", null ]
];